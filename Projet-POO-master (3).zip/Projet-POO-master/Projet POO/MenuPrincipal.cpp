#include "MenuPrincipal.h"

using namespace ProjetPOO;

void main() {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew MenuPrincipal());
}
