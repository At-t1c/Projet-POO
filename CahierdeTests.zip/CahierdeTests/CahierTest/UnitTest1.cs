using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject
{
    [TestClass]
    public class PersonnelTests
    {

        [TestMethod]
        public void Constructor_WithParameters_ShouldSetValues()
        {
            string nom = "Debels";
            string prenom = "Maxime";
            string dateEmbauche = "20-10-2020";
            string superieurHierarchique = "Dufaux";
            int idPoste = 1;

            Personnel personnel = new Personnel(nom, prenom, dateEmbauche, superieurHierarchique, idPoste);

            Assert.AreEqual(nom, personnel.get_Nom());
            Assert.AreEqual(prenom, personnel.get_Prenom());
            Assert.AreEqual(dateEmbauche, personnel.get_DateEmbauche());
            Assert.AreEqual(superieurHierarchique, personnel.get_SuperieurHierarchique());
            Assert.AreEqual(idPoste, personnel.get_ID_Poste());
        }

        [TestMethod]
        public void SettersAndGetters_ShouldUpdateAndReturnValues()
        {
  
            Personnel personnel = new Personnel();
            string updatedNom = "Satouche";
            string updatedPrenom = "Max";
            string updatedDateEmbauche = "13-02-2015";
            string updatedSuperieurHierarchique = "Johnson";
            int updatedIdPoste = 2;

            personnel.set_Nom(updatedNom);
            Assert.AreEqual(updatedNom, personnel.get_Nom());

            personnel.set_Prenom(updatedPrenom);
            Assert.AreEqual(updatedPrenom, personnel.get_Prenom());

            personnel.set_DateEmbauche(updatedDateEmbauche);
            Assert.AreEqual(updatedDateEmbauche, personnel.get_DateEmbauche());

            personnel.set_SuperieurHierarchique(updatedSuperieurHierarchique);
            Assert.AreEqual(updatedSuperieurHierarchique, personnel.get_SuperieurHierarchique());

            personnel.set_ID_Poste(updatedIdPoste);
            Assert.AreEqual(updatedIdPoste, personnel.get_ID_Poste());
        }
    }
}