#include "Personnel.h";
#include "Adresse.h";

using namespace System;
using namespace System::Data;
using namespace System::Data::SqlClient;

using namespace System;

int main(array<System::String^>^ args)
{
    Personnel^ p1 = gcnew Personnel();

    p1->set_ID_Personnel(1);
    p1->set_Nom("Debels");
    p1->set_Prenom("Maxime");
    p1->set_DateEmbauche("02-04-2004");
    p1->set_SuperieurHierarchique("Dufaux");
    p1->set_ID_Poste(3);

    Console::WriteLine("Personnel 1:");
    Console::WriteLine("ID: " + p1->get_ID_Personnel());
    Console::WriteLine("Nom: " + p1->get_Nom());
    Console::WriteLine("Prenom: " + p1->get_Prenom());
    Console::WriteLine("Date d'embauche: " + p1->get_DateEmbauche());
    Console::WriteLine("Superieur Hierarchique: " + p1->get_SuperieurHierarchique());
    Console::WriteLine("ID Poste: " + p1->get_ID_Poste());
    
    String^ nom = "Dupont";
    String^ prenom = "Max";
    String^ dateEmbauche = "20-10-2020";
    String^ superieurHierarchique = "Johnson";
    int idPoste = 1;
    Personnel^ p2 = gcnew Personnel(nom, prenom, dateEmbauche, superieurHierarchique, idPoste);

    Console::WriteLine("\nPersonnel 2:");
    Console::WriteLine("ID: " + p2->get_ID_Personnel());
    Console::WriteLine("Nom: " + p2->get_Nom());
    Console::WriteLine("Prenom: " + p2->get_Prenom());
    Console::WriteLine("Date d'embauche: " + p2->get_DateEmbauche());
    Console::WriteLine("Superieur Hierarchique: " + p2->get_SuperieurHierarchique());
    Console::WriteLine("ID Poste: " + p2->get_ID_Poste());

    Adresse^ nouvelleAdresse = gcnew Adresse(); //Adresse par d�faut

    String^ connectionString = "Data Source=MSI\MSSQL_YOANN;Initial Catalog=Projet;Integrated Security=True";
    SqlConnection^ connection = gcnew SqlConnection(connectionString);
    try {
        connection->Open();

        String^ queryPersonnel = "INSERT INTO PERSONNEL (NOM, PRENOM, DATE_EMBAUCHE, SUPERIEUR_HIERARCHIQUE, ID_POSTE) VALUES (@Nom, @Prenom, @DateEmbauche, @SuperieurHierarchique, @IDPoste)";
        SqlCommand^ commandPersonnel = gcnew SqlCommand(queryPersonnel, connection);

        commandPersonnel->Parameters->AddWithValue("@Nom", nom);
        commandPersonnel->Parameters->AddWithValue("@Prenom", prenom);
        commandPersonnel->Parameters->AddWithValue("@DateEmbauche", dateEmbauche);
        commandPersonnel->Parameters->AddWithValue("@SuperieurHierarchique", superieurHierarchique);
        commandPersonnel->Parameters->AddWithValue("@IDPoste", idPoste);
        commandPersonnel->ExecuteNonQuery();

        String^ queryGetID = "SELECT SCOPE_IDENTITY()";
        SqlCommand^ commandGetID = gcnew SqlCommand(queryGetID, connection);
        Decimal idPersonnel = (Decimal)commandGetID->ExecuteScalar();
        int idPersonnelInt = Decimal::ToInt32(idPersonnel);

        String^ queryRetrieve = "SELECT * FROM Personnel WHERE ID_PERSONNEL = @PersonnelId";
        SqlCommand^ commandRetrieve = gcnew SqlCommand(queryRetrieve, connection);
        commandRetrieve->Parameters->AddWithValue("@PersonnelId", idPersonnelInt);

        SqlDataReader^ reader = commandRetrieve->ExecuteReader();
        if (reader->Read()) {
            Console::WriteLine("\nPersonnel r�cup�r� de la BDD:");
            Console::WriteLine("ID: " + reader["ID_PERSONNEL"]);
            Console::WriteLine("Nom: " + reader["NOM"]);
            Console::WriteLine("Pr�nom: " + reader["PRENOM"]);
            Console::WriteLine("Date d'embauche: " + reader["DATE_EMBAUCHE"]);
            Console::WriteLine("Sup�rieur Hi�rarchique: " + reader["SUPERIEUR_HIERARCHIQUE"]);
            Console::WriteLine("ID Poste: " + reader["ID_POSTE"]);
        }
    }
    finally {
        connection->Close();
    }
 
     Console::ReadLine();
     return 0;
}